<?php 
include 'view/include.header.html'; 
include 'control/mail.php';
include 'view/include.mailform.php';
include 'view/include.mailform-footer.php'; 
?>