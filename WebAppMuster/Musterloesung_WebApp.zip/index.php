<form action="antwort.php" method="post">
    Sag mir, wie Du heisst:
    <input type="text" name="inpTextfeld" placeholder="Dein Name" />
    <input type="submit" value="OK" />
</form>

<br><a href="anmeldung.html">Anmeldung mit Session</a>
<br>
<br><a href="infos.php">infos.php</a>
<br>
<br><a href="control/db_connect_mysqli.php">db_connect_mysqli.php</a>
<br><a href="control/db_connect_pdo.php">db_connect_PDO.php</a>
<br>
<br><a href="hauptseite.php">Hauptseite</a>
